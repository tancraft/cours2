=== OMG Blog ===

Contributors: cyclonetheme
Tags: custom-logo, custom-menu, featured-images, threaded-comments, translation-ready, left-sidebar , right-sidebar,grid-layout,theme-options,blog ,news ,portfolio
Requires at least: 4.9
Tested up to: 5.5
Requires PHP: 5.6
Author URI: https://cyclonethemes.com/
Theme URI: 
License: GNU General Public License v3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html

== Description ==

OMG Blog is a clean and minimal blog theme for perfect for writers who need to create personal blog site with simple creative features and effects to make readers feel the pleasure of reading blog posts and articles, OMG Blog theme mixes between modern, classic and minimal styles and will help you create a simple and clean blog, if you are a blogger, then it’s a perfect choice for you if you don’t need to have any experiment to setup your Wordpress OMG Blog, it’s super simple and easy to setup, you will get high quality, responsive, well crafted blog out of the box to make writers only focuses on writing content, and it has great typography to make your fans and followers focus on every word you write.

== License ==

Bizberg WordPress Theme, Copyright 2019 CycloneTheme
Bizberg is distributed under the terms of the GNU General Public License v2

OMG Blog WordPress Theme is child theme of Bizberg WordPress Theme, Copyright 2020 CycloneTheme
OMG Blog WordPress Theme is distributed under the terms of the GNU GPL

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Screenshots ==

**** Screenshot image CCO by pxhere *****/

1. https://pxhere.com/en/photo/1026330
2. https://pxhere.com/en/photo/1028432
3. https://pxhere.com/en/photo/910012
4. https://pxhere.com/en/photo/56762