<?php
/**
 * The template for displaying author pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Kata
 */

// Don't load directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>

<header id="kata-page-title" class="kata-page-title">
	<div class="container">
		<div class="col-sm-12">
			<h3 class="kata-author-name"><?php echo esc_html( get_the_author() ); ?></h3>
		</div>
	</div>
</header> <!-- .kata-page-title -->

<?php
do_action( 'kata_index_before_loop' );

if ( Kata_Business_Helpers::advance_mode() ) {
	do_action( 'kata_author' );
} else {
	get_template_part( 'template-parts/loops/loop-author' );
}

do_action( 'kata_index_after_loop' );
get_footer();
