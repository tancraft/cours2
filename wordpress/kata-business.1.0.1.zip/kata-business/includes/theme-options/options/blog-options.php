<?php
/**
 * Blog Options.
 *
 * @author  ClimaxThemes
 * @package Kata Plus
 * @since   1.0.0
 */

// Don't load directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Kata_Business_Theme_Options_Blog' ) ) {
	class Kata_Business_Theme_Options_Blog extends Kata_Business_Theme_Options {
		/**
		 * Set Options.
		 *
		 * @since   1.0.0
		 */
		public static function set_options() {
			// Blog panel
			Kirki::add_panel(
				'kata_blog_panel',
				[
					'title'      => esc_html__( 'Blog', 'kata-business' ),
					'icon'       => 'ti-pencil-alt',
					'type' 		 => 'kirki-nested',
					'capability' => Kata_Business_Helpers::capability(),
					'priority'   => 4,
				]
			);
			Kirki::add_panel(
				'kata_blog_and_archive_panel',
				[
					'title'      => esc_html__( 'Blog & Archive', 'kata-business' ),
					'capability' => Kata_Business_Helpers::capability(),
					'icon' 		 => 'ti-layout-list-post',
					'panel'      => 'kata_blog_panel',
					'priority'   => 4,
				]
			);
			Kirki::add_panel(
				'kata_blog_post_single_panel',
				[
					'title'      => esc_html__( 'Single', 'kata-business' ),
					'capability' => Kata_Business_Helpers::capability(),
					'icon' 		 => 'ti-layout-list-post',
					'panel'      => 'kata_blog_panel',
					'priority'   => 4,
				]
			);

			// Posts
			Kirki::add_section(
				'kata_blog_posts_section',
				[
					'panel'      => 'kata_blog_and_archive_panel',
					'title'      => esc_html__( 'Posts', 'kata-business' ),
					'capability' => Kata_Business_Helpers::capability(),
				]
			);
			Kirki::add_field(
				self::$opt_name,
				[
					'type'        => 'select',
					'section'     => 'kata_blog_posts_section',
					'settings'    => 'kata_blog_posts_thumbnail_pos',
					'label'       => esc_html__( 'Thumbnail Position', 'kata-business' ),
					'default'     => 'left',
					'choices'     => [
						'left'	=> esc_html__( 'Left', 'kata-business' ),
						'right'	=> esc_html__( 'Right', 'kata-business' ),
					],
					'priority'    => 10,
				]
			);
			Kirki::add_field(
				self::$opt_name,
				[
					'type'        => 'sortable',
					'section'     => 'kata_blog_posts_section',
					'settings'    => 'kata_blog_posts_sortable_setting',
					'label'       => esc_html__( 'Post Structure', 'kata-business' ),
					'default'     => [
						'kata_post_categories',
						'kata_post_title',
						'kata_post_post_excerpt',
					],
					'choices'     => [
						'kata_post_categories'		=> esc_html__( 'Category', 'kata-business' ),
						'kata_post_title'			=> esc_html__( 'Title', 'kata-business' ),
						'kata_post_post_excerpt'	=> esc_html__( 'Post Excerpt', 'kata-business' ),
					],
					'priority'    => 10,
				]
			);
			Kirki::add_field(
				self::$opt_name,
				[
					'type'        => 'sortable',
					'section'     => 'kata_blog_posts_section',
					'settings'    => 'kata_blog_posts_metadata_sortable_setting',
					'label'       => esc_html__( 'Metadata Structure', 'kata-business' ),
					'default'     => [
						'kata_post_date',
						'kata_post_author',
					],
					'choices'     => [
						'kata_post_date'	=> esc_html__( 'Date', 'kata-business' ),
						'kata_post_author' 	=> esc_html__( 'Author', 'kata-business' ),
					],
					'priority'    => 10,
				]
			);
			Kirki::add_field(
				self::$opt_name,
				[
					'settings'        => 'kata_blog_posts_excerpt_length',
					'section'         => 'kata_blog_posts_section',
					'label'           => esc_html__('Excerpt length', 'kata-business'),
					'description'     => esc_html__('Sets the post excerpt length size', 'kata-business'),
					'type'            => 'slider',
					'default'         => 15,
					'choices'         => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				]
			);

			// First Posts
			Kirki::add_section(
				'kata_blog_first_post_section',
				[
					'panel'      => 'kata_blog_and_archive_panel',
					'title'      => esc_html__( 'First Post', 'kata-business' ),
					'capability' => Kata_Business_Helpers::capability(),
				]
			);
			Kirki::add_field(
				self::$opt_name,
				[
					'type'        => 'sortable',
					'section'     => 'kata_blog_first_post_section',
					'settings'    => 'kata_blog_first_post_sortable_setting',
					'label'       => esc_html__( 'Post Structure', 'kata-business' ),
					'default'     => [
						'kata_post_thumbnail',
						'kata_post_content',
					],
					'choices'     => [
						'kata_post_thumbnail'		=> esc_html__( 'Thumbnail', 'kata-business' ),
						'kata_post_content'			=> esc_html__( 'Content', 'kata-business' ),
					],
					'priority'    => 10,
				]
			);
			Kirki::add_field(
				self::$opt_name,
				[
					'type'        => 'sortable',
					'section'     => 'kata_blog_first_post_section',
					'settings'    => 'kata_blog_first_post_metadata_sortable_setting',
					'label'       => esc_html__( 'Metadata Structure', 'kata-business' ),
					'default'     => [
						'kata_post_date',
						'kata_post_author',
					],
					'choices'     => [
						'kata_post_date'	=> esc_html__( 'Date', 'kata-business' ),
						'kata_post_author' 	=> esc_html__( 'Author', 'kata-business' ),
					],
					'priority'    => 10,
				]
			);
			Kirki::add_field(
				self::$opt_name,
				[
					'settings'        => 'kata_blog_first_posts_excerpt_length',
					'section'         => 'kata_blog_first_post_section',
					'label'           => esc_html__('Excerpt length', 'kata-business'),
					'description'     => esc_html__('Sets the post excerpt length size', 'kata-business'),
					'type'            => 'slider',
					'default'         => 15,
					'choices'         => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				]
			);

			// Single
			Kirki::add_section(
				'kata_post_single_section',
				[
					'panel'      => 'kata_blog_panel',
					'icon'       => 'ti-pencil-alt',
					'title'      => esc_html__( 'Post Single', 'kata-business' ),
					'capability' => Kata_Business_Helpers::capability(),
				]
			);
			Kirki::add_field(
				self::$opt_name,
				[
					'type'        => 'sortable',
					'section'     => 'kata_post_single_section',
					'settings'    => 'kata_post_single_structure',
					'label'       => esc_html__( 'Post Structure', 'kata-business' ),
					'default'     => [
						'kata_post_single_thumbnail',
						'kata_post_single_title_and_meta',
						'kata_post_single_post_excerpt',
					],
					'choices'     => [
						'kata_post_single_thumbnail' 	  => esc_html__( 'Thumbnail', 'kata-business' ),
						'kata_post_single_title_and_meta' => esc_html__( 'Title and Category', 'kata-business' ),
						'kata_post_single_post_excerpt'	 => esc_html__( 'Post Excerpt', 'kata-business' ),
					],
					'priority'    => 10,
				]
			);
			Kirki::add_field(
				self::$opt_name,
				[
					'type'        => 'sortable',
					'section'     => 'kata_post_single_section',
					'settings'    => 'kata_post_single_metadata_structure',
					'label'       => esc_html__( 'Metadata Structure', 'kata-business' ),
					'default'     => [
						'kata_post_single_date',
						'kata_post_single_author',
						'kata_post_single_tags',
					],
					'choices'     => [
						'kata_post_single_date'	=> esc_html__( 'Date', 'kata-business' ),
						'kata_post_single_author' 	=> esc_html__( 'Author', 'kata-business' ),
						'kata_post_single_tags' 	=> esc_html__( 'Tags', 'kata-business' ),
					],
					'priority'    => 10,
				]
			);

		}
	} // class

	Kata_Business_Theme_Options_Blog::set_options();
}
